﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NewsFeed
{
    public class ClassRSS
    {

        public DataSet Get_RSS(string ArticleID,string Description)
        {
            string SQL = "SELECT TOP 10 ArticleID, Title, Author, Description, DatePublished,Link,Image,Author FROM News where 1=1";
            if (ArticleID != "")
            {
                SQL = SQL + " and ArticleID ='" + ArticleID + "'";
            }
            if (Description != "")
            {
                SQL = SQL + " and Description like '%" + Description + "%'";
            }
            SQL = SQL + " ORDER BY ArticleID DESC";
            //SQL = SQL + " ORDER BY DatePublished DESC";
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = SQL;
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();

            conn.Open();
            da.Fill(ds);
            conn.Close();

            return ds;
        }

        public String Inserta_News(string  Title, string Author, string Description, string DatePublished, string Link, string Image)
        {

            try
            {

                string SQL = "insert into [dbo].[News] (Title,Author,Description,DatePublished,Link,Image) ";
                SQL = SQL + "values ('" + Title + "','" + Author + "', '" + Description + "',getdate() ,'" + Link + "', '" + Image + "')";

                //ccrea la conexion a la base de datos
                SqlConnection aConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

                //crae el objeto tipo comando guarda el sql query
                SqlCommand aCommand = new SqlCommand(SQL, aConnection);

                //Abre la conexion
                aConnection.Open();
                //Realiza la consulta
                aCommand.ExecuteNonQuery();
                //cierra la conexon.
                aConnection.Close();

                return "1";
            }
            catch (Exception e)
            {
                return "0";
                //new Correos().enviarCorreo("dvelazquez@orbitacr.com;", tipoSolicitud + ":" + Usuario);
                throw e;
            }
        }

    }
}