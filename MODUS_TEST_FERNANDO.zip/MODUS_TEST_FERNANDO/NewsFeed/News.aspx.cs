﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace NewsFeed
{
    public partial class News : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ClassRSS oRSS = new ClassRSS();
            DataSet vlo_Data = new DataSet("dataSet");
            DataTable dtb_Master = new DataTable("Items");


            vlo_Data = oRSS.Get_RSS(string.Empty,string.Empty);
            vlo_Data.Tables.Add(dtb_Master);


            gvRss.DataSource = vlo_Data.Tables[0];
            gvRss.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            ClassRSS oRSS = new ClassRSS();
            DataSet vlo_Data = new DataSet("dataSet");
            DataTable dtb_Master = new DataTable("Items");

            //if (txtsearch.Text == "")
            //{
            //    MessageBox("Please put a Description o the NEWS");
            //    return;
            //}

            vlo_Data = oRSS.Get_RSS(string.Empty, txtsearch.Text);
            vlo_Data.Tables.Add(dtb_Master);


            gvRss.DataSource = vlo_Data.Tables[0];
            gvRss.DataBind();
        }
        private void MessageBox(string msg)
        {
            Label lbl = new Label();
            lbl.Text = string.Format(@"<script type='text/javascript'>alert('{0}');</script>", msg);
            Page.Controls.Add(lbl);
        }
    }
}