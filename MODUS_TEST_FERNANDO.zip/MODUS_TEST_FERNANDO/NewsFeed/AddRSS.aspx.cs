﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NewsFeed
{
    public partial class AddRSS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtTitle.Text == "")
            {
                MessageBox("Please put a Title of the NEWS");
                return;
            }
            if (txtAuthor.Text == "")
            {
                MessageBox("Please put a tAutho of the NEWS");
                return;
            }
            if (txtDescription.Text == "")
            {
                MessageBox("Please put a Description of the NEWS");
                return;
            }
            if (txtLink.Text == "")
            {
                MessageBox("Please put a Link of the NEWS");
                return;
            }
            string File = "";
            if (lblFileName.Text == "")
            {
                MessageBox("Please put a Image of the NEWS");
                return;
            }
            ClassRSS oRSS = new ClassRSS();
           
            if (lblFileName.Text != "")
            {
                File = lblFileName.Text;
            }
            else
            {
                File = "rssfeedNOImage.jpg";
            }


            oRSS.Inserta_News(txtTitle.Text, txtAuthor.Text, txtDescription.Text, System.DateTime.Now.ToLongDateString(), txtLink.Text, File);
            Response.Redirect("News.aspx");
        }

        private void MessageBox(string msg)
        {
            Label lbl = new Label();
            lbl.Text = string.Format(@"<script type='text/javascript'>alert('{0}');</script>", msg);
            Page.Controls.Add(lbl);
        }

        protected void btnSaveServer_Click(object sender, EventArgs e)
        {
            try
            {
                //Crear(write) documento en el server
                if (fluFileREquest.HasFile)
                {
                    string file_name = fluFileREquest.FileName.ToString();
                    fluFileREquest.SaveAs(Server.MapPath("images") + "\\" + fluFileREquest.FileName);
                    lblFileName.Text = "images" + "/" + fluFileREquest.FileName;
                }


            }
            catch (Exception y)
            {
                lblFileName.Text = y.Message;
            }
        }
    }
}