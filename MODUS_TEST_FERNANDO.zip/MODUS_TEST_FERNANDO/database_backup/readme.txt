two files database as backup file or script 
use like some bether for you
name of database as NewsFeed